package com.example.pokedex.pokeApi;

import com.example.pokedex.models.PokemonResponse;

import retrofit2.Call;
import retrofit2.http.GET;

public interface PokeApiService {


    @GET("pokemon")
    Call<PokemonResponse> getPokemonList();
}
